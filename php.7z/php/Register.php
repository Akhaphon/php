<!DOCTYPE html>
<html>
<body>

<h2>Register</h2>

<form action="welcome.php" method = "post">
  Username(Email only):<br>
  <input type="text" name="username" value=" "><br>

  Password:<br>
  <input type="text" name="password" value=" ">
  <br><br>
  Confirm Password:<br>
  <input type="text" name="confirmpassword" value=" ">
  <br><br>
  First Name:<br>
  <input type="text" name="firstname" value=" ">
  <br><br>
  Last Name:<br>
  <input type="text" name="lastname" value=" ">
  <br><br>
  ID Card/Passport No:<br>
  <input type="text" name="idcard" value=" ">
  <br><br>
  Date of Birth:<br>
  <input type="text" name="dateofbirth" value=" ">
  <br><br>
  Gender:<br>
  <select name="Gender">
	<option value="male">Male</option>
	<option value="female">Female</option>
   </select>
  <br><br>
   Address:<br>
  <input type="text" name="address" value=" ">
  <br><br>
  Country:<br>
  <select name="Country">
	<option value="male">Thailand</option>
	<option value="female">Korea</option>
	<option value="female">Japan</option>
	<option value="female">Taiwan</option>
	<option value="female">Vietnam</option>
	<option value="female">Hong Kong</option>
   </select>
  <br><br>
   Mobile Phone:<br>
  <input type="text" name="mobilephone" value=" ">
  <br><br>
  <p>Please complete this registration form truly. The company reserves the right in providing service if the information is not completed. The company committed to keep your information as confidential to prevent against fraud or falsely.</p>
  <br>
  <input type="submit" value="Submit">
</form> 
<a href="Home.html">Home</a>


</body>
</html>