<html>
<body>

    Welcome <?php echo $_POST["username"]; ?><br>
    Password<?php echo $_POST["password"]; ?><br>
    Confirm Password:<?php echo $_POST["confirmpassword"]; ?><br>
    First Name:<?php echo $_POST["firstname"]; ?><br>
    Last Name:<?php echo $_POST["lastname"]; ?><br>
    ID Card/Passport No:<?php echo $_POST["idcard"]; ?><br>
    Date of Birth:<?php echo $_POST["dateofbirth"]; ?><br>
    Gender:<?php echo $_POST["Gender"]; ?><br>
    Address:<?php echo $_POST["address"]; ?><br>
    Country:<?php echo $_POST["Country"]; ?><br>
    Mobile Phone:<?php echo $_POST["mobilephone"]; ?><br>
    

</body>
</html>